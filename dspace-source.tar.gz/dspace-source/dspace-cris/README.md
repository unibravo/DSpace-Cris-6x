DSpace CRIS
===========

Check the project website: http://cineca.github.com/dspace-cris/

See installation instructions at http://cineca.github.com/dspace-cris/installation.html